<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateServiceOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
{
    Schema::create('service_orders', function (Blueprint $table) {
        $table->id();
        $table->string('vehiclePlate', 7);
        $table->dateTime('entryDateTime');
        $table->dateTime('exitDateTime')->nullable();
        $table->string('priceType', 55)->nullable();
        $table->decimal('price', 12, 2)->nullable();
        $table->unsignedBigInteger('userId');
        $table->timestamps();

        $table->foreign('userId')->references('id')->on('users')->onDelete('cascade');
    });
}


    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('service_orders');
    }
}
