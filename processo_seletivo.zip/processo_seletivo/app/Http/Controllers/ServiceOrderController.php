<?php

namespace App\Http\Controllers;

use App\Models\ServiceOrder;
use Illuminate\Http\Request;

class ServiceOrderController extends Controller
{
    public function store(Request $request)
    {
        $validated = $request->validate([
            'vehiclePlate' => 'required|string|size:7',
            'entryDateTime' => 'required|date',
            'exitDateTime' => 'nullable|date|after:entryDateTime',
            'priceType' => 'nullable|string|max:55',
            'price' => 'nullable|numeric|min:0',
            'userId' => 'required|exists:users,id',
        ]);

        $serviceOrder = ServiceOrder::create($validated);
        return response()->json($serviceOrder, 201);
    }

    public function index()
    {
        $serviceOrders = ServiceOrder::with('user:id,name')->get();
        return response()->json($serviceOrders);
    }
}
