<?php

 $fillable = [
    'vehiclePlate', 'entryDateTime', 'exitDateTime', 'priceType', 'price', 'userId'
];

 function user()
{
    return $this->belongsTo(User::class, 'userId');
}
