<?php

 function serviceOrders()
{
    return $this->hasMany(ServiceOrder::class, 'userId');
}


